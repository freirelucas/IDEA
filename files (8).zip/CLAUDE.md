# IDEA-MVP — Claude Code Project Instructions
## Sintegração Sintética IPEA · Transição Ecológica · Icosaedro 12 BOTs

---

## Propósito S5 (imutável — gravado pela Presidenta Luciana Servo)

> **"Como o IPEA deve assessorar o Presidente Lula em seus planos de transição
> ecológica para o Brasil, de forma que o país lidere a agenda climática global
> COP30/pós-COP30, mantendo desenvolvimento inclusivo, justo e ambientalmente
> sustentável?"**

Este propósito é o critério de relevância de TODA saída deste projeto.
Qualquer síntese que não responda a esta pergunta foi produzida com erro de escopo.

---

## Estrutura do projeto

```
idea-mvp/
├── CLAUDE.md                    ← este arquivo
├── Makefile                     ← one-click entry points
├── src/
│   ├── sinti_runner.py          ← orquestrador principal (one-click)
│   ├── geometry.py              ← topologia do icosaedro
│   └── ipeapub_client.py        ← cliente IpeaPub RAG
├── personas/
│   ├── BOT_Luciana_S5.md        ← S5 Guardian (fora do icosaedro)
│   ├── BOT_Adriana.md           ← T1: Governança Ambiental (F/DIRUR)
│   ├── BOT_Julia.md             ← T2: Biomas e Floresta (F/DIRUR)
│   ├── BOT_Keiti.md             ← T3: Finanças Climáticas (F/DINTE)
│   ├── BOT_Amitrano.md          ← T4: Macro Ecológica (M/DIMAC)
│   ├── BOT_Leao.md              ← T5: Minerais Críticos (M/DISET)
│   ├── BOT_Gesmar.md            ← T6: Rec. Hídricos/Energia (M/DIRUR)
│   ├── BOT_Kubota.md            ← T7: IA e Trabalho (M/DISET)
│   ├── BOT_Mostafa.md           ← T8: Proteção Social (F/DISOC)
│   ├── BOT_Sambuichi.md         ← T9: Bioeconomia (F/DIRUR)
│   ├── BOT_Zucoloto.md          ← T10: CTI Verde (F/DISET)
│   ├── BOT_Igor.md              ← T11: Estado e Democracia (M/DIEST)
│   └── BOT_Fracalossi.md        ← T12: COP30/Agenda Global (M/DINTE)
├── sinTI/
│   ├── geometry/
│   │   ├── icosahedron.json     ← geometria principal (12 tópicos, 6 pares, 20 faces)
│   │   └── octahedron_c.json   ← geometria MVP anterior (6 tópicos)
│   ├── rounds/
│   │   ├── R0/                  ← Member Statements
│   │   ├── R1/                  ← Críticas Adversariais
│   │   └── R2/                  ← Statements Revisados
│   ├── synthesis/
│   │   └── IDEA.md              ← OUTPUT PRINCIPAL
│   ├── audit/
│   │   └── s5_validation.md    ← validação S5 pela BOT-Luciana
│   └── state/
│       └── sinti.log            ← log completo da sessão
└── viableos.yaml               ← configuração VSM/ViableOS
```

---

## One-click commands

```bash
make run          # sessão completa icosaedro (R0→R1→R2→R3→R4)
make run-mvp      # só octaedro (6 BOTs, mais rápido)
make dry-run      # estimativa de custo sem chamar API
make r0           # só rodada 0 (statements)
make r1           # só rodada 1 (críticas)
make synthesis    # só Observer + S5 (requer R0+R1+R2 prontos)
make clean        # limpa rodadas (preserva personas e geometria)
make audit        # relatório de proveniência e citações
```

---

## Variáveis de ambiente

```bash
export ANTHROPIC_API_KEY="..."          # obrigatório
export IPEAPUB_URL="http://localhost:8000"  # default
export MODEL_MEMBER="claude-sonnet-4-6"    # default
export MODEL_OBSERVER="claude-opus-4-6"   # default para R3
export GEOMETRY="icosahedron"              # icosahedron | octahedron
```

---

## Princípios ViableOS (imutáveis — System 5 enforcement)

| Regra | Descrição | Enforcement |
|-------|-----------|-------------|
| CR1 | Toda afirmação factual rastreável ao IpeaPub | hard_block |
| CR2 | Paridade 6F/6M em todas as rodadas | hard_block |
| CR3 | Outputs são agenda sintética, não posição IPEA oficial | watermark |
| CR4 | Todas as 6 diretorias com voz na síntese | closure_check |
| CR5 | Tensões adversariais preservadas (≥6 tensões explícitas) | divergence_floor |
| CR6 | BOTs não fazem afirmações sobre outros pesquisadores | scope_check |

**Canal algedônico:** qualquer violação → pausa + log → revisão humana obrigatória

---

## Paridade e representação (verificar antes de cada sessão)

| Diretoria | Tópico | BOT | Gênero |
|-----------|--------|-----|--------|
| DIRUR | T1 | BOT-Adriana | F |
| DIRUR | T2 | BOT-Julia | F |
| DINTE | T3 | BOT-Keiti | F |
| DIMAC | T4 | BOT-Amitrano | M |
| DISET | T5 | BOT-Leão | M |
| DIRUR | T6 | BOT-Gesmar | M |
| DISET | T7 | BOT-Kubota | M |
| DISOC | T8 | BOT-Mostafa | F |
| DIRUR | T9 | BOT-Sambuichi | F |
| DISET | T10 | BOT-Zucoloto | F |
| DIEST | T11 | BOT-Igor | M |
| DINTE | T12 | BOT-Fracalossi | M |
| **S5** | — | **BOT-Luciana** | **F** |

**Contagem:** 6F + 6M = 12 BOTs participantes + 1 S5 Guardian ✓  
**Diretorias:** DIRUR(4) · DISET(3) · DINTE(2) · DIMAC(1) · DISOC(1) · DIEST(1) ✓

---

## Open Science

- Todas as personas têm fontes rastreáveis (OpenAlex ID, Escavador, IPEA portal)
- IpeaPub RAG usa apenas publicações do repositório.ipea.gov.br
- Logs de sessão em sinTI/state/ incluem proveniência completa
- Outputs marcados com disclaimer obrigatório (CR3)
- Licença: MIT — reutilização livre com atribuição
