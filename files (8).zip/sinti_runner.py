#!/usr/bin/env python3
"""
IDEA-MVP — Sintegração Sintética · IPEA · Transição Ecológica
One-click orchestrator — Icosaedro 12 BOTs · 6F/6M · 6 Diretorias
S5 Guardian: BOT-Luciana (Presidenta IPEA)

Usage:
    make run                          # full icosahedron session
    python src/sinti_runner.py --dry-run
    python src/sinti_runner.py --round R0
    python src/sinti_runner.py --geometry sinTI/geometry/octahedron_c.json

Open Science: MIT License · Sources: OpenAlex + Escavador + repositorio.ipea.gov.br
"""

import os, json, time, logging, argparse, urllib.request
from pathlib import Path
from datetime import datetime
import anthropic

BASE    = Path(__file__).parent.parent
ROUNDS  = BASE / "sinTI/rounds"
STATE   = BASE / "sinTI/state"
AUDIT   = BASE / "sinTI/audit"
SYNTH   = BASE / "sinTI/synthesis"
PERSONA = BASE / "personas"
IPEAPUB = os.getenv("IPEAPUB_URL", "http://localhost:8000")

MODELS = {
    "member":   os.getenv("MODEL_MEMBER",   "claude-sonnet-4-6"),
    "critic":   os.getenv("MODEL_CRITIC",   "claude-sonnet-4-6"),
    "observer": os.getenv("MODEL_OBSERVER", "claude-opus-4-6"),
    "s5":       os.getenv("MODEL_S5",       "claude-sonnet-4-6"),
}

# ─── Logging ──────────────────────────────────────────────────────────────────
STATE.mkdir(parents=True, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(STATE / "sinti.log"),
        logging.StreamHandler()
    ]
)
log = logging.getLogger("sinti")

# ─── Geometry ─────────────────────────────────────────────────────────────────
def load_geo(path): return json.loads(Path(path).read_text())
def load_persona(bot_id): return (PERSONA / f"{bot_id}.md").read_text()
def get_opposite(geo, tid):
    for p in geo["opposite_pairs"]:
        if tid in p["pair"]:
            return next(x for x in p["pair"] if x != tid)

def topic_map(geo): return {t["id"]: t for t in geo["topics"]}

# ─── IpeaPub RAG ──────────────────────────────────────────────────────────────
def ipeapub(query, k=5):
    try:
        body = json.dumps({"query": query, "top_k": k}).encode()
        req  = urllib.request.Request(
            f"{IPEAPUB}/query", data=body, method="POST",
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=12) as r:
            return json.loads(r.read()).get("results", [])
    except Exception as e:
        log.warning(f"IpeaPub unavailable: {e}")
        return []

def fmt_chunks(chunks):
    if not chunks:
        return "[IpeaPub indisponível — usar publicações da persona]"
    lines = ["## Evidências IpeaPub\n"]
    for i, c in enumerate(chunks, 1):
        m = c.get("metadata", {})
        lines.append(
            f"[{i}] {m.get('titulo','?')[:70]}\n"
            f"    {m.get('autores','?')} | {m.get('ano','?')} | {m.get('tipo_conteudo','?')}\n"
            f"    {c.get('text','')[:250]}...\n")
    return "\n".join(lines)

# ─── Claude API ───────────────────────────────────────────────────────────────
def claude(system, user, model, max_tokens=2000, temp=0.7):
    client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
    msg = client.messages.create(
        model=model, max_tokens=max_tokens, temperature=temp,
        system=system, messages=[{"role":"user","content":user}])
    return msg.content[0].text

def save(path, content):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(content)

# ─── Prompts ──────────────────────────────────────────────────────────────────
PURPOSE = "Como o IPEA deve assessorar o Presidente Lula em seus planos de transição ecológica para o Brasil?"

SYS_MEMBER = """{persona}

---
RODADA 0 — MEMBER STATEMENT

Pergunta-guia S5: "{purpose}"

Escreva seu statement de abertura (700-900 palavras):
1. Parta EXCLUSIVAMENTE da sua perspectiva de diretoria e publicações reais
2. Cite ≥2 publicações das evidências IpeaPub abaixo
3. Identifique 1-2 tensões com outras diretorias
4. Termine com sua contribuição central para a agenda

{chunks}"""

SYS_CRITIC = """{persona}

---
RODADA 1 — CRÍTICA ADVERSARIAL

Você leu o statement de {opp_bot} ({opp_dir}).
Escreva crítica GENUINAMENTE ADVERSARIAL (550-700 palavras).

REGRAS ANTI-SERVILIDADE (obrigatórias):
- NÃO elogie antes de criticar
- NÃO use "o statement levanta pontos importantes, mas..."
- Identifique premissas CONTESTÁVEIS
- Aponte o que foi ignorado ou omitido
- Cite evidências IpeaPub que contradigam ou complexifiquem
- PRESERVE a tensão — não busque consenso

Statement a criticar:
{stmt}

{chunks}"""

SYS_REVISED = """{persona}

---
RODADA 2 — STATEMENT REVISADO

Você recebeu a crítica adversarial de {opp_bot}.
Escreva versão revisada (700-900 palavras) que:
1. INTEGRE tensões legítimas (não ignore nem capitule)
2. Admita lacunas reais com evidência adicional
3. Refute críticas parciais ou incorretas com dados IpeaPub
4. Mantenha sua perspectiva central — evolua, não abandone

Statement original:
{original}

Crítica recebida:
{critique}

{chunks}"""

SYS_OBSERVER = """Você é o Observer Integrador do projeto IDEA-MVP do IPEA.

Você leu {n_docs} documentos da Sintegração sobre:
"{purpose}"

Participantes (6F/6M, 6 diretorias):
{participant_list}

S5 Guardian: BOT-Luciana (Presidenta IPEA) — propósito gravado acima

Sua missão: produzir o IDEA.md — Síntese Informacional Ótima (2.800-3.800 palavras).

REGRAS OBRIGATÓRIAS:
1. A síntese NÃO é a soma das 12 perspectivas — é o que EMERGE da interação
2. Preserve EXPLICITAMENTE as {n_pairs} tensões adversariais (não aplaine)
3. Identifique insights que NENHUMA diretoria produziria sozinha
4. Cite publicações IpeaPub específicas mencionadas nas rodadas
5. Estruture como agenda de pesquisa, não relatório burocrático
6. Termine com 5-8 recomendações concretas de assessoramento ao Presidente Lula

DISCLAIMER OBRIGATÓRIO ao final:
"Este documento representa agenda de pesquisa sintética IDEA-MVP, baseada em
publicações reais do IPEA. NÃO é posição oficial do Instituto. Aprovação humana
obrigatória antes de qualquer uso externo. — Sistema IDEA-MVP, {date}"
"""

SYS_S5 = """Você é BOT-Luciana, S5 Guardian do projeto IDEA-MVP.

{persona_s5}

---
RODADA 4 — VALIDAÇÃO S5

Você leu o IDEA.md produzido pelo Observer. Sua missão é verificar:

1. O IDEA.md responde à pergunta S5 gravada?
2. Todas as 6 diretorias têm voz na síntese?
3. As {n_pairs} tensões adversariais foram preservadas (não aplainadas)?
4. Há afirmações não rastreáveis a publicações?
5. O disclaimer de CR3 está presente?

Produza relatório de validação (400-600 palavras) com:
- ✅ Conformidades
- ⚠️ Ressalvas (itens que precisam de revisão humana)
- ❌ Violações (itens que bloqueiam uso externo)
- Assinatura S5 (se aprovado) ou instrução de revisão (se reprovado)

IDEA.md para validar:
{idea_md}
"""

# ─── Rounds ───────────────────────────────────────────────────────────────────
def run_r0(geo, dry=False):
    log.info("=== R0: Member Statements ===")
    results = {}
    for t in geo["topics"]:
        bid = t["bot"]
        log.info(f"  {bid} ({t['diretoria']}/{t['gender']})")
        if dry: continue
        p  = load_persona(bid)
        cx = fmt_chunks(ipeapub(t.get("ipeapub_filter", bid)))
        sys = SYS_MEMBER.format(persona=p, purpose=PURPOSE, chunks=cx)
        r  = claude(sys, f"Elabore seu statement sobre: '{PURPOSE}'", MODELS["member"])
        results[t["id"]] = r
        save(ROUNDS/f"R0/{bid}_statement.md",
             f"# {bid} — R0 Statement\n\n{r}\n\n---\n*{datetime.now().isoformat()}*\n")
        time.sleep(1.2)
    return results

def run_r1(geo, r0, dry=False):
    log.info("=== R1: Críticas Adversariais ===")
    results = {}
    tm = topic_map(geo)
    for t in geo["topics"]:
        bid  = t["bot"]
        oid  = get_opposite(geo, t["id"])
        opp  = tm[oid]
        obid = opp["bot"]
        log.info(f"  {bid} → critica {obid}")
        if dry: continue
        stmt = r0.get(oid) or _load_file(ROUNDS/f"R0/{obid}_statement.md")
        p    = load_persona(bid)
        cx   = fmt_chunks(ipeapub(t.get("ipeapub_filter","") + " " + opp.get("ipeapub_filter","")))
        sys  = SYS_CRITIC.format(persona=p, opp_bot=obid, opp_dir=opp["diretoria"], stmt=stmt, chunks=cx)
        r    = claude(sys, f"Escreva sua crítica adversarial do statement de {obid}.", MODELS["critic"], temp=0.8)
        results[t["id"]] = r
        save(ROUNDS/f"R1/{bid}_critic.md",
             f"# {bid} → Crítica de {obid} (R1)\n\n{r}\n\n---\n*{datetime.now().isoformat()}*\n")
        time.sleep(1.2)
    return results

def run_r2(geo, r0, r1, dry=False):
    log.info("=== R2: Revisões ===")
    results = {}
    tm = topic_map(geo)
    for t in geo["topics"]:
        bid  = t["bot"]
        oid  = get_opposite(geo, t["id"])
        obid = tm[oid]["bot"]
        log.info(f"  {bid} revisa (após crítica de {obid})")
        if dry: continue
        orig    = r0.get(t["id"]) or _load_file(ROUNDS/f"R0/{bid}_statement.md")
        critique = r1.get(oid)   or _load_file(ROUNDS/f"R1/{obid}_critic.md")
        p    = load_persona(bid)
        cx   = fmt_chunks(ipeapub(t.get("ipeapub_filter", bid)))
        sys  = SYS_REVISED.format(persona=p, opp_bot=obid, original=orig, critique=critique, chunks=cx)
        r    = claude(sys, "Escreva seu statement revisado.", MODELS["member"])
        results[t["id"]] = r
        save(ROUNDS/f"R2/{bid}_revised.md",
             f"# {bid} — R2 Revisado\n\n{r}\n\n---\n*{datetime.now().isoformat()}*\n")
        time.sleep(1.2)
    return results

def run_r3(geo, dry=False):
    log.info("=== R3: Observer Síntese → IDEA.md ===")
    if dry: return ""
    docs = []
    for t in geo["topics"]:
        bid = t["bot"]
        oid = get_opposite(geo, t["id"])
        obid = topic_map(geo)[oid]["bot"]
        for tag, f in [
            ("Statement inicial", ROUNDS/f"R0/{bid}_statement.md"),
            ("Statement revisado", ROUNDS/f"R2/{bid}_revised.md"),
        ]:
            if f.exists(): docs.append(f"### {tag} — {bid} ({t['diretoria']})\n\n{f.read_text()[:1800]}\n")
    n = len(geo["topics"])
    np = len(geo["opposite_pairs"])
    plist = "\n".join(f"- {t['bot']} ({t['gender']}/{t['diretoria']}): {t['focus'][:60]}" for t in geo["topics"])
    sys = SYS_OBSERVER.format(
        n_docs=len(docs), purpose=PURPOSE, participant_list=plist,
        n_pairs=np, date=datetime.now().strftime('%d/%m/%Y'))
    user = "\n\n---\n\n".join(docs) + f"\n\n---\nProduz o IDEA.md sobre: '{PURPOSE}'"
    r = claude(sys, user, MODELS["observer"], max_tokens=4500, temp=0.5)
    header = f"""# IDEA — Síntese Informacional Ótima
## Transição Ecológica no Governo Lula: o que o IPEA sabe e o que precisa pesquisar

**Propósito S5:** {PURPOSE}  
**Data:** {datetime.now().strftime('%d/%m/%Y %H:%M')}  
**Participantes:** {n} BOTs ({geo['paridade']['F']}F/{geo['paridade']['M']}M) · 6 diretorias  
**Geometria:** {geo['geometry'].capitalize()} · {np} pares adversariais  
**S5 Guardian:** BOT-Luciana (Presidenta IPEA)

---

{r}
"""
    save(SYNTH/"IDEA.md", header)
    log.info(f"✓ IDEA.md salvo ({len(r.split())} palavras)")
    return r

def run_r4(geo, dry=False):
    log.info("=== R4: S5 Validation — BOT-Luciana ===")
    if dry: return ""
    idea = (SYNTH/"IDEA.md").read_text() if (SYNTH/"IDEA.md").exists() else "[IDEA.md não encontrado]"
    p_s5 = load_persona("BOT-Luciana_S5")
    sys  = SYS_S5.format(persona_s5=p_s5, n_pairs=len(geo["opposite_pairs"]), idea_md=idea[:6000])
    r    = claude(sys, "Valide o IDEA.md contra o propósito S5 e as regras constitucionais.", MODELS["s5"], temp=0.3)
    save(AUDIT/"s5_validation.md",
         f"# S5 Validation Report — BOT-Luciana\n\n{r}\n\n---\n*{datetime.now().isoformat()}*\n")
    log.info("✓ s5_validation.md salvo")
    return r

# ─── Helpers ──────────────────────────────────────────────────────────────────
def _load_file(p):
    return Path(p).read_text() if Path(p).exists() else "[não encontrado]"

def estimate(geo):
    n = len(geo["topics"])
    rows = [
        ("R0 Members",   n, 9_000,  1_800, "sonnet"),
        ("R1 Critics",   n, 11_000, 1_500, "sonnet"),
        ("R2 Revisions", n, 13_000, 1_800, "sonnet"),
        ("R3 Observer",  1, 38_000, 4_500, "opus"),
        ("R4 S5 Valid.", 1, 8_000,  1_200, "sonnet"),
    ]
    s_in, s_out = 3/1e6, 15/1e6
    o_in, o_out = 15/1e6, 75/1e6
    total = 0
    print("\n┌──────────────────┬───────┬───────────┬──────────┬────────┐")
    print("│ Rodada           │ Calls │ Input (K) │ Output(K)│ USD    │")
    print("├──────────────────┼───────┼───────────┼──────────┼────────┤")
    for name, calls, inp, out, m in rows:
        mi, mo = (o_in, o_out) if m=="opus" else (s_in, s_out)
        c = calls*inp*mi + calls*out*mo
        print(f"│ {name:<16} │  {calls:>3}  │  {calls*inp/1000:>7.1f}  │  {calls*out/1000:>6.1f}  │ ${c:.3f} │")
        total += c
    print("├──────────────────┼───────┼───────────┼──────────┼────────┤")
    print(f"│ TOTAL            │  {sum(r[1] for r in rows):>3}  │           │          │ ${total:.2f} │")
    print("└──────────────────┴───────┴───────────┴──────────┴────────┘")
    print(f"\n  Geometria: {geo['geometry']} · {len(geo['topics'])} tópicos · {geo['paridade']['F']}F/{geo['paridade']['M']}M")
    print(f"  Sonnet (R0-R2,R4) + Opus (R3 Observer)")
    print(f"  Custo estimado por sessão: ~USD {total:.2f}\n")

# ─── CLI ──────────────────────────────────────────────────────────────────────
def main():
    ap = argparse.ArgumentParser(description="IDEA-MVP Sintegração Sintética")
    ap.add_argument("--geometry", default=str(BASE/"sinTI/geometry/icosahedron.json"))
    ap.add_argument("--dry-run",  action="store_true")
    ap.add_argument("--round",    choices=["R0","R1","R2","R3","R4"])
    ap.add_argument("--no-rag",   action="store_true")
    args = ap.parse_args()

    geo = load_geo(args.geometry)
    print(f"\n{'='*60}")
    print(f"  IDEA-MVP · {geo['geometry'].capitalize()} · {geo['paridade']['F']}F/{geo['paridade']['M']}M")
    print(f"  S5: {geo.get('purpose_s5','?')[:65]}...")
    print(f"{'='*60}\n")

    if args.dry_run: estimate(geo); return
    if not os.getenv("ANTHROPIC_API_KEY"):
        print("❌ ANTHROPIC_API_KEY não encontrada"); return

    for d in [ROUNDS/"R0", ROUNDS/"R1", ROUNDS/"R2", STATE, AUDIT, SYNTH]:
        d.mkdir(parents=True, exist_ok=True)

    t0 = time.time()
    r0 = r1 = {}

    if not args.round or args.round == "R0": r0 = run_r0(geo)
    if not args.round or args.round == "R1": r1 = run_r1(geo, r0)
    if not args.round or args.round == "R2": run_r2(geo, r0, r1)
    if not args.round or args.round == "R3": run_r3(geo)
    if not args.round or args.round == "R4": run_r4(geo)

    log.info(f"\n✅ Concluído em {(time.time()-t0)/60:.1f} min → {SYNTH}/IDEA.md")

if __name__ == "__main__": main()
